# weather_ex

`weather_elixir`チュートリアル(第0〜10章)のコードを、章末までの最終状態としてまとめたものです。

## ⚠️ このディレクトリの生成方法について

このサンドボックス環境には Elixir/Erlang/Phoenix がインストールされておらず、`hex.pm`へのネットワークアクセスもないため、`mix phx.new`を実際に実行してプロジェクトを生成することはできませんでした。

代わりに、`weather_elixir`リポジトリの各章のコードブロックから**最終的なコード内容を人力で抽出・統合**してファイル化しています。そのため:

- **含まれるもの**: 第0〜10章で明示的にコードが示されているファイル(`lib/weather_ex/`以下のビジネスロジック、`lib/weather_ex_web/live/weather_live.ex`、JS Hook、CSS、テストなど)
- **含まれないもの**: `mix phx.new`が自動生成する定型ファイル群(`lib/weather_ex_web/endpoint.ex`本体、`lib/weather_ex_web/telemetry.ex`、`lib/weather_ex_web/gettext.ex`、`lib/weather_ex_web/components/`、`lib/weather_ex_web.ex`、`priv/gettext/`、`lib/weather_ex_web/controllers/page_*`など)。これらはチュートリアル本文にコードが載っていないため再現していません。
- 実際に使う場合は、まず `mix phx.new weather_ex --no-ecto` でこれらの定型ファイルを含む骨格を生成し、その上にこのディレクトリの `lib/`, `assets/`, `test/` の中身を上書き・追記してください。
- `mix.exs`と`config/runtime.exs`は第0,2,6,9章の記述をもとに再構成した**参考版**です。`mix phx.new`が生成する実際のバージョン番号や依存関係とは異なる可能性があります。
- `priv/static/images/whale_spritesheet.png`と`.json`(第10章)は画像アセットのため生成していません。

## 未定義だった関数について

第5章・第8章で`schedule_update/1`という関数が`mount/3`内で呼ばれていますが、チュートリアル本文には定義が示されていませんでした。`lib/weather_ex_web/live/weather_live.ex`内で「WebSocket接続確立直後に初期状態を設定し、即座に最初のデータ取得を行う」という文脈に沿う形で補って実装しています(コード内にコメントで明記)。

## 章とファイルの対応

| 章 | 主なファイル |
|---|---|
| 第0章 | `Dockerfile`, `rel/`, `config/runtime.exs`の雛形(未生成・READMEのみ) |
| 第1章 | `lib/weather_ex/weather/observation.ex`(convert_coord, sea_level_pressure, weather_emoji) |
| 第2章 | `lib/weather_ex/weather/jma_client.ex`, `mix.exs`(req追加) |
| 第3章 | `lib/weather_ex/weather/station_cache.ex`, `lib/weather_ex/application.ex` |
| 第4章 | `observation.ex`にbuild_record追加, `lib/weather_ex/weather.ex` |
| 第5章 | `lib/weather_ex_web/live/weather_live.ex`, `.html.heex`, `router.ex` |
| 第6章 | `config/runtime.exs`(デプロイ設定、コード変更なし) |
| 第7章 | `assets/js/hooks/weather_map.js`, `assets/css/app.css`, `assets/js/app.js` |
| 第8章 | `weather_live.ex`/`.html.heex`/`weather_map.js`にGeolocation機能追加 |
| 第9章 | `config/runtime.exs`(force_ssl等)、`endpoint.ex`のsession_options(部分) |
| 第10章(任意) | `weather_map.js`に鯨アニメーション追加、`.html.heex`にwhale-canvas div |
