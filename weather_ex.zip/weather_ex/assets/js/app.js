// `mix phx.new` が生成する標準のimport群(phoenix, phoenix_html,
// phoenix_live_view, topbar等)はチュートリアル本文に明示されていないため
// 省略しています。実プロジェクトでは mix phx.new が生成した app.js の
// 該当箇所に、以下のHook登録(第7章)を統合してください。

import WeatherMap from "./hooks/weather_map"

let liveSocket = new LiveSocket("/live", Socket, {
  hooks: { WeatherMap },
  params: { _csrf_token: csrfToken },
})
