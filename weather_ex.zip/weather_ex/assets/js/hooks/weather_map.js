import L from "leaflet"
import Konva from "konva"

// 第10章: 太平洋上の片道区間(日本列島から離れた海域)
const WHALE_START = [31.0, 130.0]
const WHALE_END = [34.0, 144.0]
const WHALE_SWIM_MS = 10000 // 泳いでいる時間(片道)
const WHALE_FADE_MS = 2500 // フェードイン・アウトの時間
const WHALE_INTERVAL_MS = 5 * 60 * 1000 // 出現間隔(5分)

function lerp(a, b, t) {
  return a + (b - a) * t
}

const WeatherMap = {
  mounted() {
    // --- 第7章: 地図の初期化 ---
    this.map = L.map(this.el).setView([35.5, 137.5], 6)

    L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
      attribution: "&copy; OpenStreetMap contributors",
    }).addTo(this.map)

    this.markersLayer = L.layerGroup().addTo(this.map)
    this.userLocationMarker = null

    // 第7章: サーバーからの "update_markers" イベントを購読する
    this.handleEvent("update_markers", ({ records }) => {
      this.renderMarkers(records)
    })

    // 第8章: サーバーからの「位置情報を取得して」依頼を受け取る
    this.handleEvent("start_geolocation", () => {
      this.locateUser()
    })

    // 第8章: サーバーからの「この座標にflyToして」指示を受け取る
    this.handleEvent("center_map", ({ lat, lon }) => {
      this.map.flyTo([lat, lon], 10, { animate: true, duration: 1.5 })

      if (this.userLocationMarker) {
        this.map.removeLayer(this.userLocationMarker)
      }
      this.userLocationMarker = L.circleMarker([lat, lon], {
        radius: 8,
        color: "#2563eb", // blue-600
        fillOpacity: 1,
      }).addTo(this.map)
    })

    // 第10章: 鯨アニメーション
    this.isDestroyed = false
    this.initWhale()
  },

  // ============================================================
  // 第7章: マーカー描画
  // ============================================================

  renderMarkers(records) {
    this.markersLayer.clearLayers()

    records.forEach((r) => {
      const marker = this.buildMarker(r)
      if (marker) marker.addTo(this.markersLayer)
    })
  },

  buildMarker(r) {
    if (r.diff === null) {
      return L.circleMarker([r.lat, r.lon], {
        radius: 5,
        color: "#cbd5e1", // 安定 = slate-300
        fillOpacity: 0.8,
      }).bindTooltip(`${r.name}: ${r.slp ?? "-"}hPa`)
    }

    if (r.diff <= -1.0) {
      return L.circleMarker([r.lat, r.lon], {
        radius: 7,
        color: "#a855f7", // 急落 = purple-500
        fillOpacity: 0.9,
      }).bindTooltip(`${r.name}: ${r.diff}hPa (急落)`)
    }

    if (r.diff <= -0.5) {
      return L.circleMarker([r.lat, r.lon], {
        radius: 6,
        color: "#ef4444", // 低下 = red-500
        fillOpacity: 0.85,
      }).bindTooltip(`${r.name}: ${r.diff}hPa (低下)`)
    }

    if (r.diff >= 0.5) {
      // 上昇は元のVue版と同じく三角アイコンで区別する
      return L.marker([r.lat, r.lon], {
        icon: L.divIcon({
          className: "rising-triangle-icon",
          html: '<div class="rising-triangle"></div>',
          iconSize: [12, 12],
        }),
      }).bindTooltip(`${r.name}: +${r.diff}hPa (上昇)`)
    }

    return L.circleMarker([r.lat, r.lon], {
      radius: 5,
      color: "#cbd5e1", // 安定
      fillOpacity: 0.8,
    }).bindTooltip(`${r.name}: ${r.diff}hPa`)
  },

  // ============================================================
  // 第8章: Geolocation
  // ============================================================

  locateUser() {
    if (!navigator.geolocation) {
      this.pushEvent("location_error", { reason: "unsupported" })
      return
    }

    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const { latitude, longitude } = pos.coords
        // サーバーへ座標を送り返す(JS → LiveView)
        this.pushEvent("location_found", { lat: latitude, lon: longitude })
      },
      (err) => {
        let reason = "timeout"
        switch (err.code) {
          case err.PERMISSION_DENIED:
            reason = "denied"
            break
          case err.POSITION_UNAVAILABLE:
            reason = "unavailable"
            break
          case err.TIMEOUT:
            reason = "timeout"
            break
        }
        this.pushEvent("location_error", { reason })
      },
      { enableHighAccuracy: true, timeout: 10_000, maximumAge: 0 }
    )
  },

  // ============================================================
  // 第10章: 鯨アニメーション
  // ============================================================

  async initWhale() {
    const whaleEl = this.el.querySelector("#whale-canvas")
    if (!whaleEl) return

    const stage = new Konva.Stage({
      container: whaleEl,
      width: 300,
      height: 169,
    })
    const layer = new Konva.Layer()
    stage.add(layer)

    const res = await fetch("/images/whale_spritesheet.json")
    const spriteSheetData = await res.json()

    // spriteSheetData.frames は [[x, y, width, height], ...] の形式を前提としている。
    // 各フレームインデックスを flatMap で [x, y, w, h, x, y, w, h, ...] に展開する
    // (Konva.Sprite の animations オプションが要求するフラットな数値配列にするため)
    const flatFrames = spriteSheetData.animations.swim.frames.flatMap(
      (frameIndex) => spriteSheetData.frames[frameIndex]
    )

    const image = new Image()
    image.src = "/images/whale_spritesheet.png"
    image.onload = () => {
      // fetch/画像読み込みが完了する前にページを離れ、destroyed()が
      // 先に呼ばれているケースがある。this.map は既に remove() 済み、
      // whaleEl も DOM から外れている可能性があるため、ここで打ち切る。
      if (this.isDestroyed) return

      this.whaleSprite = new Konva.Sprite({
        x: 0,
        y: 0,
        image: image,
        animation: "swim",
        animations: { swim: flatFrames },
        frameRate: spriteSheetData.framerate,
      })
      layer.add(this.whaleSprite)
      layer.draw()

      this.startWhaleSwim() // 読み込み完了後にすぐ1回泳がせる。以降5分おき
    }
  },

  startWhaleSwim() {
    if (this.isDestroyed) return

    const whaleEl = this.el.querySelector("#whale-canvas")
    const startPoint = this.map.latLngToContainerPoint(WHALE_START)
    const endPoint = this.map.latLngToContainerPoint(WHALE_END)
    const dx = endPoint.x - startPoint.x
    const dy = endPoint.y - startPoint.y
    const rotation = Math.atan2(dy, dx) * (180 / Math.PI)

    this.whaleSprite?.start()
    const startTime = performance.now()
    this.whaleAnimId = requestAnimationFrame(() =>
      this.animateWhaleSwim(startTime, rotation, whaleEl)
    )
  },

  animateWhaleSwim(startTime, rotation, whaleEl) {
    if (this.isDestroyed) return

    const elapsed = performance.now() - startTime

    if (elapsed >= WHALE_SWIM_MS) {
      whaleEl.style.opacity = 0
      this.whaleSprite?.stop()
      this.whaleTimeoutId = setTimeout(
        () => this.startWhaleSwim(),
        WHALE_INTERVAL_MS
      )
      return
    }

    const t = elapsed / WHALE_SWIM_MS
    const lat = lerp(WHALE_START[0], WHALE_END[0], t)
    const lon = lerp(WHALE_START[1], WHALE_END[1], t)
    const point = this.map.latLngToContainerPoint([lat, lon])

    let opacity
    if (elapsed < WHALE_FADE_MS) {
      opacity = elapsed / WHALE_FADE_MS
    } else if (elapsed > WHALE_SWIM_MS - WHALE_FADE_MS) {
      opacity = (WHALE_SWIM_MS - elapsed) / WHALE_FADE_MS
    } else {
      opacity = 1
    }

    whaleEl.style.transform = `translate3d(${point.x}px, ${point.y}px, 0) rotate(${rotation}deg)`
    whaleEl.style.opacity = opacity

    this.whaleAnimId = requestAnimationFrame(() =>
      this.animateWhaleSwim(startTime, rotation, whaleEl)
    )
  },

  destroyed() {
    this.isDestroyed = true
    if (this.whaleAnimId) cancelAnimationFrame(this.whaleAnimId)
    if (this.whaleTimeoutId) clearTimeout(this.whaleTimeoutId)
    if (this.map) {
      this.map.remove()
    }
  },
}

export default WeatherMap
