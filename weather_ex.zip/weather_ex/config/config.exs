import Config

# `mix phx.new`が生成する標準設定(esbuild/tailwindのプロファイル、
# pubsub、json_libraryなど)はこのファイルには含まれていません。
# 実プロジェクトでは `mix phx.new` 実行後にこのファイルとマージしてください。
#
# 第7章: esbuildがLeafletをnode_modules経由でバンドルするため、
# `cd assets && npm install leaflet` (第7章) と
# `npm install konva` (第10章) の実行が前提になります。

config :weather_ex, WeatherExWeb.Endpoint,
  render_errors: [
    formats: [html: WeatherExWeb.ErrorHTML, json: WeatherExWeb.ErrorJSON],
    layout: false
  ],
  pubsub_server: WeatherEx.PubSub

config :phoenix, :json_library, Jason

import_config "#{config_env()}.exs"
