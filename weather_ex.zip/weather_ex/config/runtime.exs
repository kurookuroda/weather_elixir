import Config

# 第0章: `mix phx.gen.release --docker` で生成されるひな型に、
# 第6章(SECRET_KEY_BASE/PHX_HOST/PORT/check_origin)と
# 第9章(force_ssl の rewrite_on)の設定を追記した最終形。
if config_env() == :prod do
  secret_key_base =
    System.get_env("SECRET_KEY_BASE") ||
      raise "SECRET_KEY_BASE が設定されていません"

  host = System.get_env("PHX_HOST") || "example.com"

  config :weather_ex, WeatherExWeb.Endpoint,
    url: [host: host, port: 443, scheme: "https"],
    # 第6章: WebSocket接続を許可するオリジン。
    # 未設定/不一致だと本番でWSだけ拒否される
    check_origin: ["https://#{host}"],
    # 第9章: Traefik(Dokploy)がTLS終端するため、コンテナ内には常にHTTPで届く。
    # X-Forwarded-Proto を信頼させないと force_ssl が無限リダイレクトを起こす
    force_ssl: [rewrite_on: [:x_forwarded_proto]],
    http: [port: String.to_integer(System.get_env("PORT") || "4000")],
    secret_key_base: secret_key_base,
    server: true
end
