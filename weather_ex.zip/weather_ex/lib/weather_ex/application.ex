defmodule WeatherEx.Application do
  @moduledoc false
  use Application

  @impl true
  def start(_type, _args) do
    children = [
      # ここにモジュール名を書くと、自動的に start_link([]) が呼ばれる
      WeatherEx.Weather.StationCache

      # NOTE: `mix phx.new` が生成する標準構成では、ここに
      # WeatherExWeb.Telemetry / Phoenix.PubSub / WeatherExWeb.Endpoint
      # なども children として並ぶが、チュートリアル本文には
      # コードが明示されていないため、StationCache 追加分のみ反映している。
      # 実プロジェクトでは mix phx.new が生成した children リストに
      # StationCache を追記する形で統合すること(第3,6章参照)。
    ]

    opts = [strategy: :one_for_one, name: WeatherEx.Supervisor]
    Supervisor.start_link(children, opts)
  end
end
