defmodule WeatherEx.Weather do
  @moduledoc """
  気象データ機能の公開API(Context)。

  呼び出し側(LiveViewなど)はこのモジュールの関数だけを呼び、
  内部で`StationCache`や`JmaClient`をどう使っているかを意識しない。
  """

  alias WeatherEx.Weather.{JmaClient, Observation, StationCache}

  @doc """
  現在の気圧・気温・天気と、1時間前との気圧差分を全観測地点分取得する。
  """
  def fetch_pressure_diffs(opts \\ []) do
    stations_fun = Keyword.get(opts, :stations_fun, &StationCache.get_stations/0)
    observation_fun = Keyword.get(opts, :observation_fun, &JmaClient.fetch_observation_pair/0)

    with {:ok, stations} <- stations_fun.(),
         {:ok, %{now: now_data, past: past_data, now_time: now_time}} <- observation_fun.() do
      {:ok, build_records(stations, now_data, past_data, now_time)}
    end
  end

  defp build_records(stations, now_data, past_data, now_time) do
    for {station_id, now_reading} <- now_data,
        past_reading = Map.get(past_data, station_id),
        not is_nil(past_reading),
        station = Map.get(stations, station_id),
        not is_nil(station),
        {:ok, record} <- [Observation.build_record(station, now_reading, past_reading, now_time)] do
      record
    end
  end
end
