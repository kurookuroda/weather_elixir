defmodule WeatherEx.Weather.JmaClient do
  @moduledoc """
  気象庁(JMA)のAMeDASデータAPIとの通信を担当する。
  すべてのパブリック関数は {:ok, data} | {:error, reason} を返す。
  """

  @base_url "https://www.jma.go.jp/bosai/amedas"

  # --- 1. Sigil と Calendar.strftime による日時フォーマット ---

  @doc """
  DateTimeを気象庁APIが要求する `YYYYMMDDHHmm00` 形式の文字列に変換する。

  ## Examples

      iex> dt = ~U[2026-08-04 12:30:00Z]
      iex> WeatherEx.Weather.JmaClient.format_jma_time(dt)
      "20260804123000"
  """
  def format_jma_time(%DateTime{} = dt) do
    Calendar.strftime(dt, "%Y%m%d%H%M") <> "00"
  end

  # --- 2. case 式によるタプルの分岐 ---

  @doc """
  最新観測時刻を取得する。
  """
  def fetch_latest_time do
    case Req.get("#{@base_url}/data/latest_time.txt") do
      {:ok, %Req.Response{status: 200, body: body}} ->
        digits = String.replace(body, ~r/\D/, "")
        {:ok, String.slice(digits, 0, 12) <> "00"}

      {:ok, %Req.Response{status: status}} ->
        {:error, {:unexpected_status, status}}

      {:error, reason} ->
        {:error, reason}
    end
  end

  @doc """
  指定時刻のAMeDASマップデータを取得する。
  """
  def fetch_map_data(target_time) do
    url = "#{@base_url}/data/map/#{target_time}.json"

    case Req.get(url) do
      {:ok, %Req.Response{status: 200, body: body}} -> {:ok, body}
      {:ok, %Req.Response{status: status}} -> {:error, {:unexpected_status, status}}
      {:error, reason} -> {:error, reason}
    end
  end

  @doc """
  観測地点マスタ(amedastable.json)を取得する。StationCacheから呼ばれる。(第3章)
  """
  def fetch_stations_master do
    case Req.get("#{@base_url}/const/amedastable.json") do
      {:ok, %Req.Response{status: 200, body: body}} -> {:ok, body}
      {:ok, %Req.Response{status: status}} -> {:error, {:unexpected_status, status}}
      {:error, reason} -> {:error, reason}
    end
  end

  # --- 3. with 構文によるハッピーパスの記述 ---

  @doc """
  最新の気圧差分計算に必要なデータペアを取得する。
  """
  def fetch_observation_pair do
    with {:ok, now_time} <- fetch_latest_time(),
         {:ok, now_dt} <- parse_jma_time(now_time),
         # <- ではなく = を使うと、マッチ失敗時にエラー(例外)ではなくそのまま変数に代入される
         past_time = shift_time(now_dt, -60),
         ten_min_ago_time = shift_time(now_dt, -10),
         {:ok, now_data} <- fetch_map_data_with_fallback(now_time, ten_min_ago_time),
         {:ok, past_data} <- fetch_map_data(past_time) do
      {:ok, %{now: now_data, past: past_data, now_time: now_time}}
    else
      # with の中で一つでも {:error, reason} にマッチしたものがあれば、
      # ここに飛んできて、そのまま呼び出し元に {:error, reason} を返す
      {:error, reason} -> {:error, reason}
    end
  end

  # プライベート関数（モジュール外からは呼べない）
  defp fetch_map_data_with_fallback(primary_time, fallback_time) do
    case fetch_map_data(primary_time) do
      {:ok, data} -> {:ok, data}
      {:error, _reason} -> fetch_map_data(fallback_time)
    end
  end

  # --- 4. バイナリパターンマッチで文字列を分解 ---

  defp parse_jma_time(time_str) do
    # 文字列を「4文字, 2文字, 2文字...」に直接分解している
    <<y::binary-4, m::binary-2, d::binary-2, h::binary-2, mi::binary-2, _::binary>> = time_str

    # non-bang版の関数を使い、タプルで結果を受け取る
    with {:ok, date} <- Date.new(String.to_integer(y), String.to_integer(m), String.to_integer(d)),
         {:ok, time} <- Time.new(String.to_integer(h), String.to_integer(mi), 0),
         {:ok, dt} <- DateTime.new(date, time) do
      {:ok, dt}
    end
  end

  defp shift_time(dt, minutes) do
    dt
    |> DateTime.add(minutes * 60) # 第3引数の :second は省略可能（デフォルト値）
    |> format_jma_time()
  end
end
