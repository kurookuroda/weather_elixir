defmodule WeatherEx.Weather.Observation do
  @moduledoc """
  気象データの純粋な変換ロジック。副作用なし。
  """

  # --- 1. モジュール属性による定数定義 ---
  @weather_emoji_map %{
    1 => "☀️", 2 => "☀️",
    3 => "☁️", 4 => "☁️",
    5 => "☔", 6 => "☔",
    7 => "❄️", 8 => "❄️",
    9 => "⚡"
  }

  # --- 2. タプルによる直接分解（パターンマッチ） ---
  @doc """
  [度, 分] のタプルを10進法の度に変換する。

  ## Examples

      iex> WeatherEx.Weather.Observation.convert_coord({35, 30})
      35.5
  """
  def convert_coord({degrees, minutes}) do
    degrees + minutes / 60.0
  end

  # --- 3. 関数の複数定義で nil ケースを先に捌く ---
  @doc """
  海面更正気圧を計算する。気圧または標高がnilならnilを返す。

  ## Examples

      iex> WeatherEx.Weather.Observation.sea_level_pressure(1000.0, 100.0, 20.0)
      1011.7

      iex> WeatherEx.Weather.Observation.sea_level_pressure(nil, 100.0, 20.0)
      nil
  """
  def sea_level_pressure(nil, _height, _temp), do: nil
  def sea_level_pressure(_pressure, nil, _temp), do: nil

  def sea_level_pressure(pressure, height, temp) do
    temp_for_calc = temp || 15.0
    result = pressure * :math.exp(0.034163 * height / (temp_for_calc + 273.15))
    Float.round(result, 1)
  end

  # --- 4. Map.getによる安全なアクセス ---
  @doc """
  天気コードを絵文字に変換する。該当なしなら空文字。

  ## Examples

      iex> WeatherEx.Weather.Observation.weather_emoji(1)
      "☀️"

      iex> WeatherEx.Weather.Observation.weather_emoji(nil)
      ""
  """
  def weather_emoji(nil), do: ""
  def weather_emoji(code), do: Map.get(@weather_emoji_map, code, "")

  # ============================================================
  # 第4章: 1観測地点分のレコード組み立て
  # ============================================================

  @doc """
  1観測地点分のデータから、表示用レコードを組み立てる。

  必要なデータ(気圧・緯度経度)が欠けている場合は `:skip` を返す。
  元のTypeScript実装の複数の `continue` 文に相当する。
  """
  def build_record(station, now_reading, past_reading, now_time) do
    with pressure_now when not is_nil(pressure_now) <-
           first_value(Map.get(now_reading, "pressure")),
         pressure_past when not is_nil(pressure_past) <-
           first_value(Map.get(past_reading, "pressure")),
         [lat_deg, lat_min | _] <- Map.get(station, "lat"),
         [lon_deg, lon_min | _] <- Map.get(station, "lon") do
      elev = Map.get(station, "elevation") || Map.get(station, "altitude") || 0
      temp_now = first_value(Map.get(now_reading, "temp"))
      # 過去の気温を正しく取得(元のTSにあった「過去slpの計算に現在気温を
      # 使ってしまうバグ」を、移植にあたって修正済み)
      temp_past = first_value(Map.get(past_reading, "temp"))

      # 現在の気圧・気温で現在の海面更正気圧を計算
      slp_now = sea_level_pressure(pressure_now * 1.0, elev * 1.0, temp_as_float(temp_now))
      # 過去の気圧・過去の気温で過去の海面更正気圧を計算
      slp_past = sea_level_pressure(pressure_past * 1.0, elev * 1.0, temp_as_float(temp_past))

      weather_code = first_value(Map.get(now_reading, "weather"))

      {:ok,
       %{
         name: Map.get(station, "kjName"),
         enname: Map.get(station, "enName"),
         lat: convert_coord({lat_deg, lat_min}),
         lon: convert_coord({lon_deg, lon_min}),
         slp: slp_now,
         diff: pressure_diff(slp_now, slp_past),
         pressure: round1(pressure_now),
         elev: elev,
         temp: temp_now && round1(temp_now),
         weather: weather_emoji(weather_code),
         time: now_time
       }}
    else
      # どれか一つでも条件を満たさなければ（マッチしなければ）:skipを返す
      _ -> :skip
    end
  end

  # --- プライベートヘルパー関数 ---

  defp first_value(nil), do: nil
  defp first_value([value | _]), do: value

  defp temp_as_float(nil), do: nil
  defp temp_as_float(temp), do: temp * 1.0

  defp round1(nil), do: nil
  defp round1(value), do: Float.round(value * 1.0, 1)

  defp pressure_diff(nil, _slp_past), do: nil
  defp pressure_diff(_slp_now, nil), do: nil
  defp pressure_diff(slp_now, slp_past), do: Float.round(slp_now - slp_past, 1)
end
