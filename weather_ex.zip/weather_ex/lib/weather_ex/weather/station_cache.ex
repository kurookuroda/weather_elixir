defmodule WeatherEx.Weather.StationCache do
  @moduledoc """
  AMeDAS観測地点マスタをプロセス内にキャッシュするGenServer。

  JSのモジュールスコープ変数(let stationsMaster)が持っていた
  「初回だけ取得してあとはメモリに保持する」という役割を、
  ElixirではGenServerの状態として持たせる。
  """

  # GenServerの機能をこのモジュールに注入する
  use GenServer

  # ==========================================
  # --- Client API（呼び出し側が使う関数） ---
  # ==========================================

  @doc """
  StationCacheプロセスを起動する。

  ## Options
    * `:name` - プロセス登録名。デフォルトは `__MODULE__`。
    * `:fetch_fun` - データを取得する関数。デフォルトは本物のJMAクライアント。
  """
  def start_link(opts \\ []) do
    # opts から :name を取り出し（無ければモジュール名）、残りを opts に戻す
    {name, opts} = Keyword.pop(opts, :name, __MODULE__)

    # opts から :fetch_fun を取り出し（無ければデフォルトの関数を設定）
    # &Module.function/arity は「関数そのもの」を変数として渡す記法
    fetch_fun =
      Keyword.get(opts, :fetch_fun, &WeatherEx.Weather.JmaClient.fetch_stations_master/0)

    # name が nil でなければ [name: name] を、nil なら [] を gen_opts にする
    gen_opts = if name, do: [name: name], else: []

    # GenServerを起動。初期状態として %{stations: nil, fetch_fun: fetch_fun} を渡す
    GenServer.start_link(__MODULE__, %{stations: nil, fetch_fun: fetch_fun}, gen_opts)
  end

  @doc """
  観測地点マスタ全体を取得する。
  """
  def get_stations(server \\ __MODULE__) do
    # 別プロセス(GenServer)に :get_stations というメッセージを送り、返信を待つ
    GenServer.call(server, :get_stations)
  end

  @doc """
  指定した観測地点IDのマスタ情報を取得する。
  """
  def get_station(server \\ __MODULE__, station_id) do
    case get_stations(server) do
      # Map.fetch はキーがあれば {:ok, value}、なければ :error を返す
      {:ok, stations} -> Map.fetch(stations, station_id)
      {:error, _reason} = error -> error
    end
  end

  # ==============================================
  # --- Server Callbacks（プロセス側の処理） ---
  # ==============================================

  @impl true
  # プロセス起動時に呼ばれる。初期状態を受け取り、そのまま返す
  def init(state) do
    {:ok, state}
  end

  @impl true
  # :get_stations メッセージを受け取った時の処理（パターン1：未取得の場合）
  # state から stations が nil と fetch_fun を取り出す（パターンマッチ）
  def handle_call(:get_stations, _from, %{stations: nil, fetch_fun: fetch_fun} = state) do
    # 注入された関数を実行する（.() は変数に入った関数を実行する構文）
    case fetch_fun.() do
      {:ok, stations} ->
        # 成功したら、state の stations にデータを入れた「新しい状態」を作って返す
        {:reply, {:ok, stations}, %{state | stations: stations}}

      {:error, reason} ->
        # 失敗したら、state は変更せずそのまま返す（エラーをキャッシュしない）
        {:reply, {:error, reason}, state}
    end
  end

  @impl true
  # :get_stations メッセージを受け取った時の処理（パターン2：取得済みの場合）
  def handle_call(:get_stations, _from, %{stations: stations} = state) do
    # そのままキャッシュ済みの stations を返す
    {:reply, {:ok, stations}, state}
  end
end
