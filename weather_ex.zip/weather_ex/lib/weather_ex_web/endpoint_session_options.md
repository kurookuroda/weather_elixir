# endpoint.ex への追記(第9章)

`lib/weather_ex_web/endpoint.ex`本体は`mix phx.new`が生成する標準ボイラープレートで、
チュートリアル本文にはコードが明示されていないため、このリポジトリでは再現していません。

第9章で言及されている、セッションCookieのセキュリティ属性の部分だけ、
`mix phx.new`実行後に生成される`endpoint.ex`内の該当箇所と見比べて確認してください。

```elixir
# lib/weather_ex_web/endpoint.ex
@session_options [
  store: :cookie,
  key: "_weather_ex_key",
  signing_salt: "your-salt-here",
  same_site: "Lax"
]
```

> `signing_salt`の値は`mix phx.new`実行時に自動生成されるランダムな文字列です。
> 実際のプロジェクトでは「your-salt-here」ではなく、生成された固有の値が
> 既に入っています。ここを手動で変更すると既存のセッションが全て無効になるため、
> 基本的に触らないでください(第9章)。

また、第10章で触れられている通り、`priv/static/images/`配下に置いた静的ファイルは
`mix phx.new`のデフォルトの`Plug.Static`設定のままで`/images/...`というURLで
自動配信されます。endpoint.ex側の追加設定は不要です。
