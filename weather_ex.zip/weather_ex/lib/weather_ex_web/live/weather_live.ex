defmodule WeatherExWeb.WeatherLive do
  use WeatherExWeb, :live_view

  alias WeatherEx.Weather

  @update_interval 300  # 5分 = 300秒
  @tick_interval 1_000  # 1秒（ミリ秒）

  # ============================================================
  # mount/3 (第5章 + 第8章でGeolocation用の初期値を追加)
  # ============================================================

  @impl true
  def mount(_params, _session, socket) do
    if connected?(socket) do
      # --- パターンB: WebSocket接続後 ---
      schedule_tick()

      {:ok,
       socket
       |> assign(locating: false, location_error: nil)
       |> schedule_update()}
    else
      # --- パターンA: 初回HTTPリクエスト時（静的レンダリング） ---
      {:ok,
       assign(socket,
         current_time: format_time(DateTime.utc_now()),
         countdown: @update_interval,
         records: [],
         loading: true,
         # NOTE: 初回描画時点で @error を参照するテンプレートがあるため
         # error: nil を明示している(チュートリアル本文では省略されていた)
         error: nil,
         locating: false,
         location_error: nil
       )}
    end
  end

  # `schedule_update/1` はチュートリアル本文(第5,8章)で呼び出されているが
  # 定義そのものは示されていなかったため補って実装している。
  # 「WebSocket接続確立直後に、未接続時と同じ初期assignsを設定した上で、
  # 5分待たずに最初のデータ取得を即座に行う」という役割として定義した。
  defp schedule_update(socket) do
    socket
    |> assign(
      current_time: format_time(DateTime.utc_now()),
      countdown: @update_interval,
      records: [],
      loading: true,
      error: nil
    )
    |> fetch_weather()
  end

  # ============================================================
  # Step 2 (第5章): Process.send_after によるタイマー
  # ============================================================

  @impl true
  def handle_info(:tick, socket) do
    new_countdown = socket.assigns.countdown - 1

    socket =
      if new_countdown <= 0 do
        socket
        |> fetch_weather()
        |> assign(countdown: @update_interval)
      else
        assign(socket, countdown: new_countdown)
      end

    # ★ 次の1回をスケジュール
    schedule_tick()

    {:noreply, assign(socket, current_time: format_time(DateTime.utc_now()))}
  end

  defp schedule_tick do
    Process.send_after(self(), :tick, @tick_interval)
  end

  # ============================================================
  # 第8章: Geolocationの往復
  # ============================================================

  @impl true
  def handle_event("locate_user", _params, socket) do
    {:noreply,
     socket
     |> assign(locating: true, location_error: nil)
     |> push_event("start_geolocation", %{})}
  end

  @impl true
  def handle_event("location_found", %{"lat" => lat, "lon" => lon}, socket) do
    {:noreply,
     socket
     |> assign(locating: false)
     |> push_event("center_map", %{lat: lat, lon: lon})}
  end

  @impl true
  def handle_event("location_error", %{"reason" => reason}, socket) do
    message =
      case reason do
        "denied" -> "位置情報の利用が許可されていません。ブラウザの設定を確認してください。"
        "unavailable" -> "現在地を取得できませんでした。電波状況の良い場所で再度お試しください。"
        "unsupported" -> "お使いのブラウザは位置情報に対応していません。"
        _ -> "位置情報の取得がタイムアウトしました。再度お試しください。"
      end

    {:noreply, socket |> assign(locating: false, location_error: message)}
  end

  # ============================================================
  # Step 3 (第5章 + 第7章): データ取得とpush_event
  # ============================================================

  defp fetch_weather(socket) do
    case Weather.fetch_pressure_diffs() do
      {:ok, records} ->
        socket
        |> assign(records: records, loading: false, error: nil)
        |> push_event("update_markers", %{records: Enum.map(records, &marker_payload/1)})

      {:error, reason} ->
        assign(socket, error: reason, loading: false)
    end
  end

  defp marker_payload(record) do
    %{
      name: record.name,
      lat: record.lat,
      lon: record.lon,
      diff: record.diff,
      slp: record.slp
    }
  end

  defp format_time(%DateTime{} = dt) do
    dow = ["日", "月", "火", "水", "木", "金", "土"] |> Enum.at(Date.day_of_week(dt) - 1)
    Calendar.strftime(dt, "%Y年%m月%d日(#{dow}) %H:%M:%S")
  end

  defp format_countdown(seconds) do
    m = div(seconds, 60)
    s = rem(seconds, 60)
    "#{m}:#{String.pad_leading("#{s}", 2, "0")}"
  end
end
