defmodule WeatherExWeb.Router do
  use WeatherExWeb, :router

  # `mix phx.new` 標準の pipeline定義(:browser, :api等)は
  # チュートリアル本文にコードが明示されていないため省略しています。
  # 実プロジェクトでは mix phx.new が生成した router.ex に
  # 以下の scope を統合してください。

  scope "/", WeatherExWeb do
    pipe_through :browser

    get "/", PageController, :home        # ← 既存（従来のController）
    live "/weather", WeatherLive          # ← 第5章で追加（LiveView）
  end
end
