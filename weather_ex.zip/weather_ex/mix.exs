defmodule WeatherEx.MixProject do
  use Mix.Project

  def project do
    [
      app: :weather_ex,
      version: "0.1.0",
      elixir: "~> 1.17",
      elixirc_paths: elixirc_paths(Mix.env()),
      start_permanent: Mix.env() == :prod,
      deps: deps()
    ]
  end

  # `mix phx.new weather_ex --no-ecto` により自動生成される標準の
  # Application設定・releases設定はこのファイルには含まれていません。
  # 実プロジェクトでは `mix phx.new` 実行後にこのファイルとマージしてください。
  def application do
    [
      mod: {WeatherEx.Application, []},
      extra_applications: [:logger, :runtime_tools]
    ]
  end

  defp elixirc_paths(:test), do: ["lib", "test/support"]
  defp elixirc_paths(_), do: ["lib"]

  defp deps do
    [
      # --no-ecto のため Ecto/Postgrex は含まれない(第0章)
      {:phoenix, "~> 1.8"},
      {:phoenix_live_view, "~> 1.0"},
      {:phoenix_html, "~> 4.0"},
      {:esbuild, "~> 0.8", runtime: Mix.env() == :dev},
      {:tailwind, "~> 0.2", runtime: Mix.env() == :dev},
      {:telemetry_metrics, "~> 1.0"},
      {:telemetry_poller, "~> 1.0"},
      {:jason, "~> 1.4"},
      {:bandit, "~> 1.5"},

      # 第2章: JMA APIとの通信用HTTPクライアント
      {:req, "~> 0.5"}
    ]
  end
end
