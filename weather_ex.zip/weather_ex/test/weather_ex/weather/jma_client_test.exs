defmodule WeatherEx.Weather.JmaClientTest do
  use ExUnit.Case, async: true
  doctest WeatherEx.Weather.JmaClient
  alias WeatherEx.Weather.JmaClient

  describe "format_jma_time/1" do
    test "DateTimeを気象庁形式の文字列に変換する(末尾00付き14桁)" do
      dt = ~U[2026-08-04 12:30:00Z]
      assert JmaClient.format_jma_time(dt) == "20260804123000"
    end

    test "1桁の月日時分もゼロパディングされる" do
      dt = ~U[2026-01-05 03:07:00Z]
      assert JmaClient.format_jma_time(dt) == "20260105030700"
    end
  end

  # fetch_latest_time等のネットワーク関数はここではテストしない。
  # 動作確認は iex で行うこと。
  # （発展：Req.Test や Mox を使ったモックテストは今後の章で扱います）
end
