defmodule WeatherEx.Weather.ObservationTest do
  # テストモジュールにCaseの機能を読み込む（async: true で並行実行を許可）
  use ExUnit.Case, async: true

  # @doc 内の Examples をテストとして実行する魔法の一行
  doctest WeatherEx.Weather.Observation

  alias WeatherEx.Weather.Observation

  # describe でテストをグループ化できる（RSpecの describe と同じ）
  describe "convert_coord/1" do
    # アリティ（引数の数）を名前の後ろに /1 のように書くのがElixirの慣習
    test "度分を10進法に変換する" do
      # assert は左辺と右辺が一致するか検証する
      assert Observation.convert_coord({35, 30}) == 35.5
    end

    test "分が0のとき度そのまま" do
      assert Observation.convert_coord({36, 0}) == 36.0
    end
  end

  describe "sea_level_pressure/3" do
    test "気圧・標高・気温から海面更正気圧を計算する" do
      assert Observation.sea_level_pressure(1000.0, 100.0, 20.0) == 1011.7
    end

    test "気圧がnilならnilを返す" do
      assert Observation.sea_level_pressure(nil, 100.0, 20.0) == nil
    end

    test "気温がnilなら15.0度として計算する" do
      result = Observation.sea_level_pressure(1000.0, 100.0, nil)
      assert result == Observation.sea_level_pressure(1000.0, 100.0, 15.0)
    end
  end

  describe "weather_emoji/1" do
    test "既知のコードは絵文字を返す" do
      assert Observation.weather_emoji(1) == "☀️"
      assert Observation.weather_emoji(9) == "⚡"
    end

    test "未知のコードは空文字" do
      assert Observation.weather_emoji(99) == ""
    end

    test "nilは空文字" do
      assert Observation.weather_emoji(nil) == ""
    end
  end

  # 第4章: build_record/4
  describe "build_record/4" do
    test "slp・diffは海面更正気圧の計算式に沿った値になる(過去の気温をslpPastに使う)" do
      station = %{"lat" => [35, 41], "lon" => [139, 46], "elevation" => 25, "kjName" => "東京"}
      now = %{"pressure" => [1005.2, 0], "temp" => [28.5, 0]}
      past = %{"pressure" => [1006.0, 0], "temp" => [26.0, 0]}  # 過去の気温をセット

      {:ok, record} = Observation.build_record(station, now, past, "t")

      # 現在の気圧・現在の気温で計算
      expected_slp_now = Observation.sea_level_pressure(1005.2, 25.0, 28.5)
      # 過去の気圧・過去の気温で計算（ここが正しい仕様）
      expected_slp_past = Observation.sea_level_pressure(1006.0, 25.0, 26.0)
      expected_diff = Float.round(expected_slp_now - expected_slp_past, 1)

      assert record.slp == expected_slp_now
      assert record.diff == expected_diff
    end

    test "過去データが無い、または気圧がnilなら:skipになる" do
      now = %{"pressure" => [1005.2, 0]}
      past = %{"pressure" => [nil, 0]} # 欠測

      assert :skip == Observation.build_record(%{}, now, past, "t")
    end
  end
end
