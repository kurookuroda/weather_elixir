defmodule WeatherEx.Weather.StationCacheTest do
  use ExUnit.Case, async: true
  alias WeatherEx.Weather.StationCache

  # テスト用のヘルパー関数：ダミーのfetch_funを注入して起動する
  defp start_cache(fetch_fun) do
    # name: nil にすることで、テストごとに独立した「無名プロセス」として起動する
    {:ok, pid} = StationCache.start_link(name: nil, fetch_fun: fetch_fun)
    pid
  end

  test "初回のget_stationsでfetch_funを実行し、結果を返す" do
    # ダミーデータを返すだけの関数を注入
    fetch_fun = fn -> {:ok, %{"47759" => %{"kjName" => "東京"}}} end
    pid = start_cache(fetch_fun)

    # 注入した pid を指定して呼び出す
    assert {:ok, %{"47759" => %{"kjName" => "東京"}}} = StationCache.get_stations(pid)
  end

  test "2回目以降はfetch_funを再実行せずキャッシュを返す" do
    # 呼ばれた回数を数えるための「状態を持つ小さなプロセス(Agent)」を準備
    {:ok, counter} = Agent.start_link(fn -> 0 end)

    fetch_fun = fn ->
      # 呼ばれるたびにカウントを増やす
      Agent.update(counter, &(&1 + 1))
      {:ok, %{"47759" => %{"kjName" => "東京"}}}
    end

    pid = start_cache(fetch_fun)

    # 3回呼び出す
    StationCache.get_stations(pid)
    StationCache.get_stations(pid)
    StationCache.get_stations(pid)

    # カウンタが1のままである＝fetch_funは1回しか呼ばれていない（キャッシュされている）
    assert Agent.get(counter, & &1) == 1
  end

  test "fetch_funが失敗を返す場合、エラーを返しキャッシュしない" do
    {:ok, counter} = Agent.start_link(fn -> 0 end)

    fetch_fun = fn ->
      Agent.update(counter, &(&1 + 1))
      {:error, :network_error}
    end

    pid = start_cache(fetch_fun)

    assert {:error, :network_error} = StationCache.get_stations(pid)
    assert {:error, :network_error} = StationCache.get_stations(pid)

    # 失敗時はキャッシュされないので、毎回fetch_funが呼ばれてカウントが2になる
    assert Agent.get(counter, & &1) == 2
  end

  test "get_station/2で存在しないIDは:errorを返す(Map.fetchの挙動)" do
    fetch_fun = fn -> {:ok, %{"47759" => %{"kjName" => "東京"}}} end
    pid = start_cache(fetch_fun)

    assert :error = StationCache.get_station(pid, "99999")
  end
end
