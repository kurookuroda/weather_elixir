defmodule WeatherEx.WeatherTest do
  use ExUnit.Case, async: true
  alias WeatherEx.Weather

  test "過去データに存在しない地点は結果から除外される(元のTSのcontinueに相当)" do
    stations_fun = fn -> {:ok, %{"47759" => %{"kjName" => "東京", "lat" => [35, 41], "lon" => [139, 46]}}} end

    observation_fun = fn ->
      {:ok,
       %{
         now: %{
           "47759" => %{"pressure" => [1005.2, 0]},
           "99999" => %{"pressure" => [1008.0, 0]} # 過去データが無い地点
         },
         past: %{"47759" => %{"pressure" => [1006.0, 0]}},
         now_time: "t"
       }}
    end

    # ダミー関数を注入
    {:ok, records} =
      Weather.fetch_pressure_diffs(stations_fun: stations_fun, observation_fun: observation_fun)

    # 99999は除外され、東京の1件だけになる
    assert length(records) == 1
    assert hd(records).name == "東京"
  end
end
