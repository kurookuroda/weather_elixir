defmodule WeatherExWeb.WeatherLiveTest do
  use WeatherExWeb.ConnCase, async: true
  import Phoenix.LiveViewTest

  test "マウント時に時刻とカウントダウンが表示される", %{conn: conn} do
    {:ok, _view, html} = live(conn, "/weather")

    assert html =~ "気圧変化アラート"
    assert html =~ "UPDATE IN:"
  end

  test ":tickメッセージでカウントダウンが減少する", %{conn: conn} do
    {:ok, view, _html} = live(conn, "/weather")

    # 初期カウントダウンは300
    assert render(view) =~ "UPDATE IN: 5:00"

    # 直接:tickメッセージを送信（1秒待たずにテスト）
    send(view.pid, :tick)
    html = render(view)

    # 299秒 = 4:59
    assert html =~ "UPDATE IN: 4:59"
  end

  test "カウントダウン0でデータ更新がトリガーされる", %{conn: conn} do
    {:ok, view, _html} = live(conn, "/weather")

    # assignを直接書き換えてカウントダウンを1にする（テスト用ショートカット）
    :sys.replace_state(view.pid, fn state ->
      %{state | assigns: %{state.assigns | countdown: 1}}
    end)

    # tickを送ると0になり、Weather.fetch_pressure_diffs/0 が呼ばれる
    send(view.pid, :tick)
    html = render(view)

    # 実際にAPIからデータが取れていれば気圧値が含まれる
    assert html =~ "hPa"
  end
end
